httplib2
========

The official mirror of httplib2.